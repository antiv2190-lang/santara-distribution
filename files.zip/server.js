// Santara Distribution — serveur central
// Sert l'application web ET stocke les données dans une base MongoDB partagée,
// afin que le PC et les téléphones voient toujours les mêmes informations.

const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
require('dotenv').config();

const app = express();
app.use(express.json({ limit: '5mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// ---------- Base de données ----------
const MONGODB_URI = process.env.MONGODB_URI;
if (!MONGODB_URI) {
  console.error('ERREUR : la variable d\'environnement MONGODB_URI est manquante. Voir README.md.');
  process.exit(1);
}

mongoose.connect(MONGODB_URI)
  .then(() => console.log('Connecté à la base de données.'))
  .catch(err => {
    console.error('Impossible de se connecter à la base de données :', err.message);
    process.exit(1);
  });

// Toute l'application partage un seul document d'état (comme avant, mais côté serveur).
const StateSchema = new mongoose.Schema({
  singleton: { type: String, default: 'santara', unique: true },
  data: { type: mongoose.Schema.Types.Mixed, required: true },
  updatedAt: { type: Date, default: Date.now }
});
const StateModel = mongoose.model('AppState', StateSchema);

// ---------- API : lecture / écriture des données ----------
app.get('/api/state', async (req, res) => {
  try {
    const doc = await StateModel.findOne({ singleton: 'santara' });
    res.json(doc ? doc.data : null);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Erreur de lecture des données.' });
  }
});

app.post('/api/state', async (req, res) => {
  try {
    await StateModel.findOneAndUpdate(
      { singleton: 'santara' },
      { data: req.body, updatedAt: new Date() },
      { upsert: true }
    );
    res.json({ ok: true });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Erreur d\'enregistrement des données.' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Santara Distribution en écoute sur le port ${PORT}`));
